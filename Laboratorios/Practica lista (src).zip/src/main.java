import Listas.Lista;

public class main {

    public static void main(String[] args) {
        Lista lista = new Lista();
        lista.llenarLista("Carlos", "Beta", "Nobel", "Luis", "Carla", "Robson", "Luly", "Celmira", "Ram", "Daniela");
        lista.imprimir();
    }
}