CREATE DATABASE BaseFinal
USE BaseFinal
clientesCREATE TABLE Clientes (
  numero_cedula VARCHAR(20) PRIMARY KEY,
   tipo_cliente VARCHAR(15),
  nombre VARCHAR(100),
  fecha_nacimiento VARCHAR(20),
  genero VARCHAR(10),
  correo VARCHAR(100),
  numero_telefono VARCHAR(20),
  provincia VARCHAR(50),
  ciudad VARCHAR(50),
  corregimiento VARCHAR(50),
  cantidad_promedio_gastada DECIMAL(10, 2),
  productos_frecuentes VARCHAR(255),
  descuento DECIMAL(7, 2),
  asesor_asignado VARCHAR(100),
  cantidad_credito DECIMAL(10, 2),
  membresia int
);
CREATE TABLE Productos (
    id INT(10) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    codigo_barras VARCHAR(50) NOT NULL,
    precio_estandar DECIMAL(10, 2) NOT NULL,
    precio_descuento DECIMAL(10, 2)
);
CREATE TABLE Compras (
    NumeroCompra INT PRIMARY KEY,
    cedula varchar(50),
    nombre_producto varchar(20),
    cantidad_productos int, 
    CostoTotal DECIMAL(10, 2),
    ITBMS DECIMAL(10, 2),
    FechaCompra VARCHAR(20)
); 

crear los 3 usuario en mariadb
administrador;123
usuario2;124
estudiante;estudiante




nombre de la base de datos: basefinal
puerto 3307
url:jdbc:mariadb://localhost:3307/basefinal
