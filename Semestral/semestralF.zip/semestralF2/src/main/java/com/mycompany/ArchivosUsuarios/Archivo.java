/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ArchivosUsuarios;

import com.mycompany.Entity.Usuariosdb;
import java.io.File;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Javier Chong
 */
public class Archivo {
    String ruta = System.getProperty("user.home") + "/Desktop/usuarios.txt";
    public Archivo() {
    }
    
    
    
    
    public boolean crearArchivo() {

        try {
            
            File milota = new File(ruta);  
             return milota.createNewFile();

        } catch (IOException ex) {
            System.out.println("\n\nOcurrio un error\n\n");
            Logger.getLogger(Archivo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    
    
    public String leerArchivo(String nombre) throws IOException{
        
        File archivo = new File(ruta);
        
        Usuariosdb db = new Usuariosdb();
        try (Scanner scanner = new Scanner(archivo)) {
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                String[] partes = linea.split(";"); // Separar usando el delimitador
       
                if (partes.length == 3 && partes[2].equals(nombre)) {
                    Usuariosdb.setUsuario(partes[0]);
                    Usuariosdb.setContraseña(partes[1]); 
                    db.setNombre(partes[2]); 
                    System.out.println("se registro el usuario "+partes[2]);
                }
            }
        }catch(Exception e){
            System.out.println("esta algo mal escrito");
        }
        return null;
    }
    
    public void IngresarDatos () {
try {
    try (FileWriter escribir = new FileWriter(ruta)) {
        escribir.write("administrador;123;Administrador\n");
        escribir.write("usuario2;124;Mario\n");
        escribir.write("estudiante;estudiante;usuarioRoot\n");
    }
    System.out.println("<----- Datos Guardados Exitosamnete ----->");
} catch (IOException e) {
    System.out.println("-----Ocurrio un error-----");
}
}
    
    }


