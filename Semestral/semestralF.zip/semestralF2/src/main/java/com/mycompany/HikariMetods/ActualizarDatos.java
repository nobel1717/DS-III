package com.mycompany.HikariMetods;

import com.mycompany.Entity.ClienteVip;
import com.mycompany.Entity.Compras;
import com.mycompany.Entity.Productos;
import com.mycompany.HikariCP.ConexionHikari;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.sun.tools.javac.Main;
import java.sql.ResultSet;

public class ActualizarDatos {

    public void actualizarDatos(String tipo, ClienteVip cliente) {
        try (Connection connect = ConexionHikari.getConnection();
             PreparedStatement statement = connect.prepareStatement(
                "UPDATE clientes SET tipo_cliente=?, nombre=?, fecha_nacimiento=?, genero=?, correo=?, " +
                "numero_telefono=?, provincia=?, ciudad=?, corregimiento=?, descuento=?, asesor_asignado=?, " +
                "cantidad_credito=?, membresia=? WHERE numero_cedula=?")) {

            statement.setString(1, tipo);
            statement.setString(2, cliente.getNombre());
            statement.setString(3, cliente.getFechaNacimiento());
            statement.setString(4, cliente.getGenero());
            statement.setString(5, cliente.getCorreo());
            statement.setString(6, cliente.getTelefono());
            statement.setString(7, cliente.getProvincia());
            statement.setString(8, cliente.getCiudad());
            statement.setString(9, cliente.getCorregimiento());
            statement.setDouble(10, cliente.getDescuento());
            statement.setString(11, cliente.getAsesor());
            statement.setDouble(12, cliente.getCredito());
            statement.setInt(13, cliente.getNumeroMembresia());
            statement.setString(14, cliente.getCedula());

            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Se actualizó la información exitosamente.");
            } else {
                System.out.println("No se encontró ningún cliente con la cédula proporcionada.");
            }

        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void actualizarProducto(Productos producto) {
        try (Connection connect = ConexionHikari.getConnection();
             PreparedStatement statement = connect.prepareStatement(
                "UPDATE Productos SET nombre=?, codigo_barras=?, precio_estandar=?, precio_descuento=? WHERE id=?")) {

            statement.setString(1, producto.getNombrePro());
            statement.setString(2, producto.getCodigoBarra());
            statement.setDouble(3, producto.getPrecioStandart());
            statement.setDouble(4, producto.getPrecioDescuento());
            statement.setInt(5, producto.getId());

            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Se actualizó la información del producto exitosamente.");
            } else {
                System.out.println("No se encontró ningún producto con el ID proporcionado.");
            }

        } catch (SQLException ex) {
            Logger.getLogger(ActualizarDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    

        public void actualizarCompra(String cedula,Compras venta) {
        try (Connection connect = ConexionHikari.getConnection();
             PreparedStatement statement = connect.prepareStatement(
                "UPDATE compras SET cedula=?, nombre_producto=?, cantidad_productos=?, CostoTotal=?, ITBMS=?, FechaCompra=? WHERE NumeroCompra=?")) {

            statement.setString(1, cedula);
            statement.setString(2, venta.getNombrePro());
            statement.setInt(3, venta.getCantidadProducto());
            statement.setDouble(4, venta.getCostoTotal());
            statement.setDouble(5, venta.getItbms());
            statement.setString(6, venta.getFechaCompra());
            statement.setInt(7, venta.getNumeroCompra());


            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Se actualizó la información del producto exitosamente.");
            } else {
                System.out.println("No se encontró ningún producto con el ID proporcionado.");
            }

        } catch (SQLException ex) {
            Logger.getLogger(ActualizarDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        //actualizar y agregar los productos frecuentes y promedio gastao
public void actualizarOperacion() throws SQLException {
    Consultas consulta = new Consultas();

    try (Connection connect = ConexionHikari.getConnection();
         PreparedStatement statement = connect.prepareStatement("SELECT numero_cedula FROM clientes")) {

        ResultSet resultSet = statement.executeQuery();

        while (resultSet.next()) {
            String cedula = resultSet.getString("numero_cedula");

            String sql = "UPDATE clientes SET cantidad_promedio_gastada = ?, productos_frecuentes = ? WHERE numero_cedula = ? AND tipo_cliente not like('OCASIONAL')";
            try (PreparedStatement updateStatement = connect.prepareStatement(sql)) {

                double promedioGastado = consulta.PromedioGastado(cedula);
                String productosFrecuentes = consulta.Productosfrecuentes(cedula);
                updateStatement.setDouble(1, promedioGastado);
                updateStatement.setString(2, productosFrecuentes);
                updateStatement.setString(3, cedula);

                updateStatement.executeUpdate();
            }catch (SQLException ex) {
        Logger.getLogger(ActualizarDatos.class.getName()).log(Level.SEVERE, null, ex);
    }
        }

    } catch (SQLException ex) {
        Logger.getLogger(ActualizarDatos.class.getName()).log(Level.SEVERE, null, ex);
    }
}
    
    
    }
