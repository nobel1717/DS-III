/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.Entity;

/**
 *
 * @author Javier Chong
 */
public class Usuariosdb {
    private static String usuario;
    private static String contraseña;
    private String nombre;

    
    
    
    public static String getUsuario() {
        return usuario;
    }

    public static void setUsuario(String usuario) {
        Usuariosdb.usuario = usuario;
    }

    public static String getContraseña() {
        return contraseña;
    }

    public static void setContraseña(String contraseña) {
        Usuariosdb.contraseña = contraseña;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
    
}
