  /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.Entity;
import com.mycompany.HikariMetods.IngresoDatos;

public class ClienteVip extends ClienteFrecuente{
    private String asesor;
    private double credito;
    //tengaaa piedad xD
    IngresoDatos ing = new IngresoDatos();
    
    public ClienteVip() {
        this.asesor = "";
        this.credito = 0.0;
    }

    public ClienteVip(String asesor, double credito) {
        this.asesor = asesor;
        this.credito = credito;
    }

    public ClienteVip(String asesor, double credito, int numeroMembresia, double cantidadPromedioGastado, String productoCompradoFrecuente, double descuento, String nombre, String cedula, String genero, String fechaNacimiento, String telefono, String provincia, String ciudad, String corregimiento, String correo) {
        super(numeroMembresia, cantidadPromedioGastado, productoCompradoFrecuente, descuento, nombre, cedula, genero, fechaNacimiento, telefono, provincia, ciudad, corregimiento, correo);
        this.asesor = asesor;
        this.credito = credito;
    }



 
 

    
    
    public String getAsesor() {
        return asesor;
    }

    public void setAsesor(String asesor) {
        this.asesor = asesor;
    }

    public double getCredito() {
        return credito;
    }

    public void setCredito(double credito) {
        this.credito = credito;
    }
    
    
    
}
