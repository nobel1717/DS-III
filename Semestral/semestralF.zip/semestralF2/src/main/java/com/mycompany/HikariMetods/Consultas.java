/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.HikariMetods;

import com.mycompany.HikariCP.ConexionHikari;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Javier Chong
 */
public class Consultas {
    List<String> productosF = new ArrayList<>();
        List<String> datos = new ArrayList<>();

    private double monto;
    private String producto;
    

    public Consultas() {
    }
    
    
    
    public String Productosfrecuentes(String cedula){
        try (Connection connect = ConexionHikari.getConnection();
    PreparedStatement statement = connect.prepareStatement("SELECT nombre_producto, MAX(cantidad_productos) AS total_comprado " +
                     "FROM compras " +
                     "WHERE cedula = ? " +
                     "GROUP BY nombre_producto " +
                     "ORDER BY total_comprado DESC LIMIT 1");)
        {
      
        statement.setString(1, cedula);
 
        ResultSet resultSet = statement.executeQuery();
        
        while(resultSet.next()){
            producto = resultSet.getString("nombre_producto");
        }
        
  
        
    }catch (SQLException ex) {
        Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
        }
        return producto;
    }
    
    
        public double PromedioGastado(String cedula){
        try (Connection connect = ConexionHikari.getConnection();
    PreparedStatement statement = connect.prepareStatement("SELECT AVG(CostoTotal) AS promedio FROM compras WHERE cedula = ?");)
        {
      
        statement.setString(1, cedula);
 
        ResultSet resultSet = statement.executeQuery();
        
        while(resultSet.next()){
            monto = resultSet.getDouble("promedio");
        }
        
        
    }catch (SQLException ex) {
        Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
        }
        return monto; 
    }
        
        
        
        //##############################################################################################################
        //##############################################################################################################
        /*Metodo para mostrar todos los datos de los cientes mediante la cedula*/
       public List<String> ConsultarCliente(String comoConsultar, String tabla,String valor){
           try(Connection connect = ConexionHikari.getConnection();
               PreparedStatement statement = 
                connect.prepareStatement("SELECT * FROM "+ tabla+" WHERE "+comoConsultar+" = ? "))
     {
         
        statement.setString(1, valor);
 
        ResultSet resultSet = statement.executeQuery();
        
        while(resultSet.next()){
          /*guardo la informacion en la lista que cree*/
          datos.add(resultSet.getString("numero_cedula"));
          datos.add(resultSet.getString("tipo_cliente"));
          datos.add(resultSet.getString("nombre"));
          datos.add(resultSet.getString("fecha_nacimiento"));
          datos.add(resultSet.getString("genero"));
          datos.add(resultSet.getString("correo"));
          datos.add(resultSet.getString("numero_telefono"));
          datos.add(resultSet.getString("provincia"));
          datos.add(resultSet.getString("ciudad"));
          datos.add(resultSet.getString("corregimiento"));
          datos.add(String.valueOf(resultSet.getDouble("cantidad_promedio_gastada")));
          datos.add(resultSet.getString("productos_frecuentes"));
          datos.add(String.valueOf(resultSet.getDouble("descuento")));
          datos.add(resultSet.getString("asesor_asignado"));
          datos.add(String.valueOf( resultSet.getDouble("cantidad_credito")));
          datos.add(String.valueOf(resultSet.getInt("membresia")));
          
        }
        
        
           } catch (SQLException ex) {
            Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
        }
           return datos;
       }
       
       
       
       //##################################################################################################
       
     public List<String> ConsultarCompra( String tabla,String valor){
           try(Connection connect = ConexionHikari.getConnection();
               PreparedStatement statement = 
                connect.prepareStatement("SELECT * FROM "+ tabla+" WHERE NumeroCompra = ? "))
     {
         
        statement.setString(1, valor);
 
        ResultSet resultSet = statement.executeQuery();
        
        while(resultSet.next()){
          /*guardo la informacion en la lista que cree*/
          datos.add(String.valueOf(resultSet.getInt("NumeroCompra")));
          datos.add(String.valueOf(resultSet.getInt("cedula")));
          datos.add(resultSet.getString("nombre_producto"));
          datos.add(String.valueOf(resultSet.getInt("cantidad_productos")));
          datos.add(String.valueOf(resultSet.getDouble("CostoTotal")));
          
          datos.add(String.valueOf(resultSet.getDouble("ITBMS")));
          datos.add(resultSet.getString("FechaCompra"));
          
          
        }
        
        
           } catch (SQLException ex) {
            Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
        }
           return datos;
       }
              
              //#####################################################################################
           public List<String> ConsultarProductos( String tabla,String valor){
           try(Connection connect = ConexionHikari.getConnection();
               PreparedStatement statement = 
                connect.prepareStatement("SELECT * FROM "+ tabla+" WHERE id = ? "))
     {
         
        statement.setString(1, valor);
 
        ResultSet resultSet = statement.executeQuery();
        
        while(resultSet.next()){
          /*guardo la informacion en la lista que cree*/
          datos.add(String.valueOf(resultSet.getInt("id")));
          datos.add(resultSet.getString("nombre"));
          datos.add(String.valueOf(resultSet.getString("codigo_barras")));
          datos.add(String.valueOf(resultSet.getDouble("precio_estandar")));
          datos.add(String.valueOf(resultSet.getDouble("precio_descuento")));

        }
        
        
           } catch (SQLException ex) {
            Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
        }
           return datos;
       }
}
