
package com.mycompany.HikariMetods;

/**
 *
 * @author User
 */


import com.mycompany.Entity.ClienteVip;
import com.mycompany.Entity.Compras;
import com.mycompany.Entity.Productos;
import com.mycompany.HikariCP.ConexionHikari;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.sun.tools.javac.Main;
//import java.util.StringJoiner;
import javax.swing.JOptionPane;

/**
 *
 * @author Javier Chong
 */
public class IngresoDatos {


    public IngresoDatos() {
        
    }
    
    
    
    //nombre, cedula, genero, fechaNacimiento, telefono, provincia, ciudad corregimiento, correo
    public String ingreso(String tipo, ClienteVip cliente){
        try (Connection connect = ConexionHikari.getConnection();
    PreparedStatement statement = connect.prepareStatement("insert into clientes(numero_cedula, tipo_cliente,nombre, fecha_nacimiento, genero"+
            ", correo, numero_telefono, provincia, ciudad, corregimiento,cantidad_promedio_gastada, productos_frecuentes, descuento, asesor_asignado, cantidad_credito, membresia)"
            + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");){
          Consultas consulta = new Consultas();

        statement.setString(1, cliente.getCedula());
        statement.setString(2, tipo);
        statement.setString(3, cliente.getNombre());
        statement.setString(4, cliente.getFechaNacimiento());
        statement.setString(5, cliente.getGenero());
        statement.setString(6, cliente.getCorreo());
        statement.setString(7, cliente.getTelefono());
        statement.setString(8, cliente.getProvincia());
        statement.setString(9, cliente.getCiudad());
        statement.setString(10, cliente.getCorregimiento());
        statement.setDouble(11, consulta.PromedioGastado(cliente.getCedula()));//cantidad_promedio_gastada
        statement.setString(12, consulta.Productosfrecuentes(cliente.getCedula()));//productos_frecuentes
        statement.setDouble(13, cliente.getDescuento());
        statement.setString(14, cliente.getAsesor());
        statement.setDouble(15, cliente.getCredito());
        statement.setInt(16, cliente.getNumeroMembresia());

        
        
        statement.executeUpdate();
        JOptionPane.showMessageDialog(null, "Se guardó el cliente: " +cliente.getNombre()+ " como: "+tipo );
    }catch (SQLException ex) {
        Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }


    public void ingresoProducto(Productos producto) {
        try (Connection connect = ConexionHikari.getConnection();
             PreparedStatement statement = connect.prepareStatement(
                "INSERT INTO Productos (id,nombre, codigo_barras, precio_estandar, precio_descuento) " +
                "VALUES (?,?, ?, ?, ?)");) {
            statement.setInt(1, producto.getId());
            statement.setString(2, producto.getNombrePro());
            statement.setString(3, producto.getCodigoBarra());
            statement.setDouble(4, producto.getPrecioStandart());
            statement.setDouble(5, producto.getPrecioDescuento());

            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Se guardó la el producto: "+producto.getNombrePro() );
            

        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
   public void ingresoCompra(String cedula, Compras venta) {
        try (Connection connect = ConexionHikari.getConnection()) {
            //StringJoiner joiner = new StringJoiner(", "); // Especifica el separador entre elementos
            
            String query = "INSERT INTO Compras(NumeroCompra, cedula, nombre_producto, cantidad_productos, CostoTotal, ITBMS, FechaCompra) VALUES (?, ?, ?, ?, ?, ?,?)";
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setInt(1, venta.getNumeroCompra());
            statement.setString(2, cedula);
            statement.setString(3, venta.getNombrePro());
            statement.setInt(4, venta.getCantidadProducto());
            statement.setDouble(5, venta.getCostoTotal());
            statement.setDouble(6, venta.getItbms());
            System.out.println("ingreso datos "+venta.getFechaCompra());
            statement.setString(7, venta.getFechaCompra());

            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Se guardó la compra del producto: " + venta.getNombrePro());
            

        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }



}
