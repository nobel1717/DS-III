/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.Entity;

/**
 *
 * @author Javier Chong
 */
public class Compras extends Productos{
    private int numeroCompra;
    private double costoTotal;
    private double itbms;
    private String fechaCompra;
    private int cantidadProducto;

    public Compras(int numeroCompra, double costoTotal, double itbms, String fechaCompra, int cantidadProducto) {
        this.numeroCompra = numeroCompra;
        this.costoTotal = costoTotal;
        this.itbms = itbms;
        this.fechaCompra = fechaCompra;
        this.cantidadProducto = cantidadProducto;
    }

    public Compras() {
    }

    public Compras(int numeroCompra, double costoTotal, double itbms, String fechaCompra, int cantidadProducto, String nombrePro) {
        super(nombrePro);
        this.numeroCompra = numeroCompra;
        this.costoTotal = costoTotal;
        this.itbms = itbms;
        this.fechaCompra = fechaCompra;
        this.cantidadProducto = cantidadProducto;
        
        
    }

    
    
    
    
    public int getNumeroCompra() {
        return numeroCompra;
    }

    public void setNumeroCompra(int numeroCompra) {
        this.numeroCompra = numeroCompra;
    }

    public double getCostoTotal() {
        return costoTotal;
    }

    public void setCostoTotal(double costoTotal) {
        this.costoTotal = costoTotal;
    }

    public double getItbms() {
        return itbms;
    }

    public void setItbms(double itbms) {
        this.itbms = itbms;
    }

    public String getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(String fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public int getCantidadProducto() {
        return cantidadProducto;
    }

    public void setCantidadProducto(int cantidadProducto) {
        this.cantidadProducto = cantidadProducto;
    }
    
    
    
    
    
    
   
}
