
package com.mycompany.HikariMetods;

import com.mycompany.HikariCP.ConexionHikari;
import com.sun.tools.javac.Main;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class EliminarDatos {

    // ... other code ...

    public String eliminar(String cedula) throws SQLException {
        try (Connection connect = ConexionHikari.getConnection();
             PreparedStatement statement = connect.prepareStatement("DELETE FROM Clientes WHERE numero_cedula = ?");) {

            statement.setString(1, cedula);

            System.out.println("Se borró.");
            statement.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
        public String eliminarProducto(int id) throws SQLException {
        try (Connection connect = ConexionHikari.getConnection();
             PreparedStatement statement = connect.prepareStatement("DELETE FROM Productos WHERE id = ?");) {

            statement.setInt(1, id);

            System.out.println("Producto eliminado.");
            statement.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
        
        
  public String EliminarCompra(int numeroCompra) throws SQLException {
        try (Connection connect = ConexionHikari.getConnection();
             PreparedStatement statement = connect.prepareStatement("DELETE FROM compras WHERE NumeroCompra = ?");) {

            statement.setInt(1, numeroCompra);

            System.out.println("compra eliminado.");
            statement.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}

