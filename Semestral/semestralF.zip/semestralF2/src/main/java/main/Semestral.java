
package main;

import com.mycompany.ArchivosUsuarios.Archivo;
import vistas.Usuarios;






/**
 *
 * @author brayan
 */
public class Semestral {


    public static void main(String[] args) {
        Archivo arch = new Archivo();
        if(arch.crearArchivo()){
            arch.IngresarDatos();
        }else{
            System.out.println("ya existe un archivo");
        }
        Usuarios user = new Usuarios();
        user.setVisible(true);
        user.setLocationRelativeTo(null);
        
    }

    
}
